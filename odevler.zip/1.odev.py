
for a in range(1,101):
    if a%3==0:
        if a%5==0:
            print("FizzBuzz")
        else:
            print("Buzz")
    else:
        print(a)
